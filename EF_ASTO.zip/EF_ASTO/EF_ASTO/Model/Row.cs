﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_ASTO.Model
{
    public class Row
    {
        public int RowId { get; set; }
        public string RowName { get; set; }
    }
}
