﻿using EF_ASTO.DAL.DbContexts;
using EF_ASTO.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace EF_ASTO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder();
            // установка пути к текущему каталогу
            builder.SetBasePath(Directory.GetCurrentDirectory());
            // получаем конфигурацию из файла appsettings.json
            builder.AddJsonFile("appsettings.json");
            // создаем конфигурацию
            var config = builder.Build();
            // получаем строку подключения
            var connectionString = config.GetConnectionString("DefaultConnection");
            //Console.WriteLine(connectionString);
            var optionsBuilder = new DbContextOptionsBuilder<AstoDbContext>();
            var options = optionsBuilder.UseSqlServer(connectionString).Options;

            using (AstoDbContext db = new AstoDbContext(options))
            {
                Row row1 = new() { RowName = "Row_01" };
                Row row2 = new Row() { RowName = "Row_02" };
                Row row3 = new Row() { RowName = "Row_03" };
                Row row4 = new Row() { RowName = "Row_04" };

                Column column1 = new Column() { ColumnName = "Column_01" };
                Column column2 = new Column() { ColumnName = "Column_02" };
                Column column3 = new Column() { ColumnName = "Column_03" };
                Column column4 = new Column() { ColumnName = "Column_04" };
                Column column5 = new Column() { ColumnName = "Column_05" };

                db.Rows.AddRange(row1, row2, row3, row4);
                db.Columns.AddRange(column1, column2, column3, column4);   

                db.SaveChanges();

                var rows = db.Rows.ToList();
                foreach (Row row in rows)
                    Console.WriteLine($"{row.RowId}.{row.RowName}");
            }
        }
    }
}
